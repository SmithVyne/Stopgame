# Website for parsing stopgame.ru

### Requirements:
- Django
- requests
- BeautifulSoup4
- lxml

### How to use:
- Install required python libraries
- Open a terminal in a folder containing manage.py (in your IDE or just your OS terminal)
- Type "python manage.py runserver" in the terminal to start the script.
- Go to http://127.0.0.1:8000/
- Enjoy
